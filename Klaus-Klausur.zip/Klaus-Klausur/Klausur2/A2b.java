package Klausur.Klausur2;
import annotation.author;

// Aufgabe 2b in Beispielklausur 2 für PR1 SoSe2024 

@author(name = "Lucas Harnisch")
public class A2b {
    

    public static void main(String[] args) {
        
        int a = 2;
        int b = 1;

        for (int i = 0; i<3; b *= a-b, i++) {
            a += a*i;
            System.out.println("Value of a: " + a);
            System.out.println("Value of b: " + b +"\n");

        }

        System.out.println("Final values: ");
        System.out.println("a = " + a);
        System.out.println("b = "+ b);
 

        
    }


    

}
